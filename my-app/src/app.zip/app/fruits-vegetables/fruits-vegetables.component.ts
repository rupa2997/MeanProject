import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fruits-vegetables',
  templateUrl: './fruits-vegetables.component.html',
  styleUrls: ['./fruits-vegetables.component.css']
})
export class FruitsVegetablesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
