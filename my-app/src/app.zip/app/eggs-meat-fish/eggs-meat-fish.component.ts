import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eggs-meat-fish',
  templateUrl: './eggs-meat-fish.component.html',
  styleUrls: ['./eggs-meat-fish.component.css']
})
export class EggsMeatFishComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
