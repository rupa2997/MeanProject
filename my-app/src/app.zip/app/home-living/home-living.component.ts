import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-living',
  templateUrl: './home-living.component.html',
  styleUrls: ['./home-living.component.css']
})
export class HomeLivingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  added() {
    let ru = sessionStorage.getItem('sid')
    console.log(ru);

  }

}
