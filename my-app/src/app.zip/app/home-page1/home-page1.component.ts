import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-page1',
  templateUrl: './home-page1.component.html',
  styleUrls: ['./home-page1.component.css']
})
export class HomePage1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
