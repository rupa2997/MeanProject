import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beauty-hygiene',
  templateUrl: './beauty-hygiene.component.html',
  styleUrls: ['./beauty-hygiene.component.css']
})
export class BeautyHygieneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
